// lib/pricebuddy.ts — server-only. لا تستورده في مكوّنات الواجهة.
const BASE = process.env.PRICEBUDDY_BASE_URL!; // مثال: https://pb.example.com/api
const TOKEN = process.env.PRICEBUDDY_API_TOKEN!;

export type Row = {
  id: number;
  title: string;
  category: "جديد" | "مستعمل" | "غير مصنف";
  current: number | null;
  best: number | null;
  change: number | null; // نسبة مئوية عن المتوسط
  history: number[];
  urls: { url: string; store?: string }[];
};

async function pb(path: string, init?: RequestInit) {
  const res = await fetch(`${BASE}${path}`, {
    ...init,
    headers: {
      Authorization: `Bearer ${TOKEN}`,
      Accept: "application/json",
      "Content-Type": "application/json",
      ...(init?.headers || {}),
    },
    cache: "no-store",
  });
  if (!res.ok) throw new Error(`PriceBuddy ${res.status}`);
  return res.json();
}

const num = (v: any) => (v === undefined || v === null || isNaN(Number(v)) ? null : Number(v));

// ⚠️ طبقة التحويل: لو شكل استجابة PriceBuddy اختلف، عدّل هنا فقط.
function normalize(p: any): Row {
  const ins = p.insights ?? {};
  const stats = ins.stats ?? p.stats ?? {};
  const current = num(stats.current ?? p.current_price ?? p.price);
  const avg = num(stats.average);
  const tags: string[] = (p.tags ?? []).map((t: any) => (typeof t === "string" ? t : t.name));
  const history = (ins.history ?? p.history ?? [])
    .map((h: any) => num(typeof h === "number" ? h : h.price))
    .filter((n: number | null): n is number => n !== null);
  return {
    id: p.id,
    title: p.title ?? p.name,
    category: tags.includes("جديد") ? "جديد" : tags.includes("مستعمل") ? "مستعمل" : "غير مصنف",
    current,
    best: num(ins.bestPrice ?? stats.lowest ?? current),
    change: current && avg ? ((current - avg) / avg) * 100 : null,
    history,
    urls: (p.urls ?? []).map((u: any) => ({ url: u.url, store: u.store?.name })),
  };
}

// كاش 5 دقائق في الذاكرة (يكفي لعدد قليل من الموظفين).
let cache: { at: number; rows: Row[] } | null = null;
const TTL = 5 * 60 * 1000;

export async function getRows(force = false) {
  if (!force && cache && Date.now() - cache.at < TTL) return { ...cache, stale: false };
  try {
    const json = await pb("/products?include=insights");
    cache = { at: Date.now(), rows: (json.data ?? json).map(normalize) };
    return { ...cache, stale: false };
  } catch (e) {
    if (cache) return { ...cache, stale: true }; // آخر بيانات مع تنبيه
    throw e;
  }
}

export async function addUrl(productId: number, url: string) {
  cache = null;
  return pb(`/products/${productId}/urls`, { method: "POST", body: JSON.stringify({ url }) });
}
