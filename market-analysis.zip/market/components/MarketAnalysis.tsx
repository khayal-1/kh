"use client";
import { useCallback, useEffect, useMemo, useState } from "react";
import "./market.css";

type Row = {
  id: number; title: string; category: "جديد" | "مستعمل" | "غير مصنف";
  current: number | null; best: number | null; change: number | null;
  history: number[]; urls: { url: string; store?: string }[];
};
type Filter = "all" | "جديد" | "مستعمل";
const fmt = (n: number | null) => (n == null ? "—" : n.toLocaleString("ar-EG") + " ج.م");

function Spark({ data, w = 90, h = 26 }: { data: number[]; w?: number; h?: number }) {
  if (data.length < 2) return <span className="mk-muted">بيانات غير كافية</span>;
  const min = Math.min(...data), max = Math.max(...data), r = max - min || 1;
  const pts = data.map((v, i) => `${(i / (data.length - 1)) * w},${h - ((v - min) / r) * (h - 4) - 2}`).join(" ");
  const up = data[data.length - 1] >= data[0];
  return (
    <svg width={w} height={h} aria-hidden>
      <polyline points={pts} fill="none" stroke={up ? "var(--mk-up)" : "var(--mk-down)"} strokeWidth="1.8" />
    </svg>
  );
}

function Change({ v }: { v: number | null }) {
  if (v == null || Math.abs(v) < 0.1) return <span className="mk-muted">—</span>;
  return <span className={v > 0 ? "mk-up" : "mk-down"}>{v > 0 ? "↑" : "↓"} {Math.abs(v).toFixed(1)}%</span>;
}

export default function MarketAnalysis() {
  const [rows, setRows] = useState<Row[]>([]);
  const [q, setQ] = useState("");
  const [filter, setFilter] = useState<Filter>("all");
  const [sel, setSel] = useState<Row | null>(null);
  const [newUrl, setNewUrl] = useState("");
  const [err, setErr] = useState<string | null>(null);
  const [stale, setStale] = useState(false);
  const [at, setAt] = useState<number | null>(null);
  const [loading, setLoading] = useState(false);

  const load = useCallback(async (force = false) => {
    setLoading(true);
    try {
      const res = await fetch(`/api/market/prices${force ? "?refresh=1" : ""}`);
      const json = await res.json();
      if (!res.ok) throw new Error(json.error);
      setRows(json.rows); setStale(json.stale); setAt(json.at); setErr(null);
    } catch (e: any) {
      setErr(e.message || "تعذر تحديث الأسعار، حاول لاحقاً"); // نبقي آخر بيانات معروضة
    } finally { setLoading(false); }
  }, []);

  // عرض دائم: تحديث تلقائي كل 10 دقائق
  useEffect(() => { load(); const t = setInterval(() => load(), 10 * 60 * 1000); return () => clearInterval(t); }, [load]);

  const shown = useMemo(() => rows.filter(r =>
    (filter === "all" || r.category === filter) && r.title.toLowerCase().includes(q.trim().toLowerCase())
  ), [rows, filter, q]);

  async function addUrl() {
    if (!sel || !newUrl) return;
    const res = await fetch(`/api/market/products/${sel.id}/urls`, {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ url: newUrl }),
    });
    const json = await res.json();
    if (!res.ok) return setErr(json.error);
    setNewUrl(""); load(true);
  }

  return (
    <main className="mk" dir="rtl">
      <header className="mk-head">
        <h1>تحليل السوق</h1>
        <input className="mk-search" placeholder="ابحث عن موديل…" value={q} onChange={e => setQ(e.target.value)} />
        <div className="mk-toggle" role="group" aria-label="الفئة">
          {([["all", "الكل"], ["جديد", "جديد فقط"], ["مستعمل", "مستعمل فقط"]] as [Filter, string][]).map(([k, l]) => (
            <button key={k} aria-pressed={filter === k} onClick={() => setFilter(k)}>{l}</button>
          ))}
        </div>
        <button className="mk-refresh" onClick={() => load(true)} disabled={loading}>{loading ? "جارٍ التحديث…" : "تحديث الآن"}</button>
      </header>

      {err && <p className="mk-warn" role="alert">{err}</p>}
      {stale && !err && <p className="mk-warn">البيانات المعروضة من آخر تحديث ناجح.</p>}
      {at && <p className="mk-muted">آخر تحديث: {new Date(at).toLocaleTimeString("ar-EG")}</p>}

      <div className="mk-scroll">
        <table className="mk-table">
          <thead><tr><th>الموديل</th><th>الفئة</th><th>سعر السوق اليوم</th><th>التغير</th><th>اتجاه 7 أيام</th><th>أفضل سعر</th></tr></thead>
          <tbody>
            {shown.map(r => (
              <tr key={r.id} onClick={() => setSel(r)} tabIndex={0} onKeyDown={e => e.key === "Enter" && setSel(r)}>
                <td>{r.title}</td><td>{r.category}</td><td>{fmt(r.current)}</td>
                <td><Change v={r.change} /></td><td><Spark data={r.history.slice(-7)} /></td><td>{fmt(r.best)}</td>
              </tr>
            ))}
            {!shown.length && <tr><td colSpan={6} className="mk-muted">لا توجد موديلات مطابقة. أضف موديلاً في PriceBuddy ليظهر هنا.</td></tr>}
          </tbody>
        </table>
      </div>

      {sel && (
        <aside className="mk-panel" role="dialog" aria-label={sel.title}>
          <button className="mk-close" onClick={() => setSel(null)}>إغلاق</button>
          <h2>{sel.title}</h2>
          <Spark data={sel.history} w={320} h={90} />
          <h3>الروابط المراقبة</h3>
          <ul>{sel.urls.map(u => <li key={u.url}><a href={u.url} target="_blank" rel="noreferrer">{u.store || u.url}</a></li>)}</ul>
          <div className="mk-add">
            <input placeholder="رابط إعلان جديد" value={newUrl} onChange={e => setNewUrl(e.target.value)} />
            <button onClick={addUrl}>إضافة للمراقبة</button>
          </div>
        </aside>
      )}
    </main>
  );
}
