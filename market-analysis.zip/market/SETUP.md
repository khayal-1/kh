# تشغيل وحدة تحليل السوق

## 1) PriceBuddy على VPS (ليس على Vercel)
    mkdir pricebuddy && cd pricebuddy
    wget https://raw.githubusercontent.com/jez500/pricebuddy/main/docker-compose.yml
    touch .env
    docker compose up -d
ادخل http://SERVER:8080 وغيّر admin@example.com / admin فوراً، ثم ضع دومين + HTTPS.
أنشئ API Token من قائمة المستخدم > API tokens.

## 2) متغيرات البيئة (Vercel > Settings > Environment Variables، وفي .env.local محلياً)
    PRICEBUDDY_BASE_URL=https://pb.yourdomain.com/api
    PRICEBUDDY_API_TOKEN=xxxxxxxx
(بدون NEXT_PUBLIC_ حتى لا يظهر الـ Token في المتصفح.)

## 3) الملفات
انسخ المجلدات إلى جذر المشروع (أو src/ لو تستخدمه): lib/ و app/ و components/.
تأكد أن alias "@/" يشير للجذر في tsconfig.

## 4) زر القائمة
    <Link href="/market">تحليل السوق</Link>

## 5) اختبار سريع
1. أضف 2–3 موديلات في PriceBuddy بوسم "جديد" أو "مستعمل" ورابط إعلان لكل منها.
2. افتح /api/market/prices — يجب أن ترى JSON فيه rows.
3. افتح /market — الجدول يظهر، وزر "تحديث الآن" يتجاوز الكاش.
4. أوقف PriceBuddy مؤقتاً وحدّث: تظهر "تعذر تحديث الأسعار" مع بقاء آخر بيانات.

## مهم
- requireStaff في route.ts حالياً يرجع true: اربطه بتحقق Supabase Auth قبل النشر.
- لو ظهرت الأعمدة فارغة، افتح /products/1?include=insights على PriceBuddy وعدّل دالة normalize في lib/pricebuddy.ts.
