import MarketAnalysis from "@/components/MarketAnalysis";
export const metadata = { title: "تحليل السوق" };
export default function Page() { return <MarketAnalysis />; }
