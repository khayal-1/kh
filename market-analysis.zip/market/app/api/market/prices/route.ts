// الوسيط (Proxy) الذي يحمي الـ Token
import { NextResponse } from "next/server";
import { getRows } from "@/lib/pricebuddy";

export const dynamic = "force-dynamic";

// TODO: اربطه بنفس تحقق الأدمن/الموظف المستخدم في موقعك (Supabase Auth).
async function requireStaff(_req: Request) { return true; }

export async function GET(req: Request) {
  if (!(await requireStaff(req))) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const force = new URL(req.url).searchParams.get("refresh") === "1";
  try {
    return NextResponse.json(await getRows(force));
  } catch {
    return NextResponse.json({ error: "تعذر تحديث الأسعار، حاول لاحقاً" }, { status: 502 });
  }
}
