import { NextResponse } from "next/server";
import { addUrl } from "@/lib/pricebuddy";

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const { url } = await req.json();
  try { new URL(url); } catch { return NextResponse.json({ error: "رابط غير صالح" }, { status: 400 }); }
  try {
    await addUrl(Number(id), url);
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ error: "تعذرت إضافة الرابط" }, { status: 502 });
  }
}
